<?php

namespace OpenCloud\Common\Exceptions;

class InvalidParameterError extends \Exception {}
