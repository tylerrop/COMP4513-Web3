<?php

namespace OpenCloud\Common\Exceptions;

class InvalidIpTypeError extends \Exception {}
