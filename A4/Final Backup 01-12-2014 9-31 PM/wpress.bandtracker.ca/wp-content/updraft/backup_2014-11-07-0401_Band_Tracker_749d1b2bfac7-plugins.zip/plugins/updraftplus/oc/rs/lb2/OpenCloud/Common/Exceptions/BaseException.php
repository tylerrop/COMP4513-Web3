<?php

namespace OpenCloud\Common\Exceptions;

class BaseException extends \Exception
{
}