<?php

namespace OpenCloud\Common\Exceptions;

class AsyncHttpError extends \Exception {}
