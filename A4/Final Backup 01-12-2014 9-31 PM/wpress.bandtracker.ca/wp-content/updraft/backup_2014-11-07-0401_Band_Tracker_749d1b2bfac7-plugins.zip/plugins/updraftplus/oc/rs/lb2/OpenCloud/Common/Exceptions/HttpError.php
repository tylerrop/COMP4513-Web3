<?php

namespace OpenCloud\Common\Exceptions;

class HttpError extends \Exception {}
