Testimonial Basics Plugin - Translation Ready
==============================================

1) I believe the plug in is ready for translation.
2) I have included  testiminial-basics.pot which you can load into Poedit to do your translation.
3) For anyone who goes through the trouble to translate the plugin to a different language, send me the 
   .po files and I will add the translation to the next release.
4) The French and Dutch translations were initially done by 

    French - Stephanie Lariviere, Quebec
   
    but there has been significant revisions which I have completed using Google Translate, not the 
    best way to do it and both translations will need to be revised.
    
    Dutch - Hans Fontijin, Netherlands, updated by Vincent Volmer, Netherlands
    
    Spanish - Graciela Brinda
    
	Germam - Frank Schofisch, Germany