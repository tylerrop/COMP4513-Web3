<div class="col-md-8">
	<div class="error_404">
		<h2><?php _e('404','weblizar'); ?></h2>
		<h4><?php _e('Whoops... Post Not Found !!!','weblizar'); ?></h4>
		<p><?php _e('We`re sorry, but the page you are looking for doesn`t exist.','weblizar'); ?></p>
		<p><a href="<?php echo home_url( '/' ); ?>"><button class="enigma_send_button" type="submit"><?php _e('Go To Homepage','weblizar'); ?></button></a></p>
	</div>
</div>